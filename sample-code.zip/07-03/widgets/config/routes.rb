Rails.application.routes.draw do
  resources :widgets, only: [ :show, :index ]


  ####
  # Custom routes start here
  #
  # For each new custom route:
  #
  # * Be sure you have the canonical route declared above
  # * Add the new custom route below the existing ones
  # * Document why it's needed
  # * Explain anything else non-standard

  # Used in podcast ads for the 'amazing' campaign
# START:edit:3
  get "/amazing", to: "widgets#index"
# END:edit:3

end
